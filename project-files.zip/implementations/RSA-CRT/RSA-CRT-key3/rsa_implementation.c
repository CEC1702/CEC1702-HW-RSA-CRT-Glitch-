/*
    This file is part of the ChipWhisperer Example Targets
    Copyright (C) 2016-2017 NewAE Technology Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "__rsa_defines.h"
#include "rsa_implementation.h"
#include "simpleserial/simpleserial.h"
#include "device_setup/cec1702_setup.h"
#include "BIGI/bigi.h"
#include "BIGI/bigi_io.h"
#include "debug.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#define RSA_BYTES (RSA_BITS  >> 3)
#define RSA_WORDS (RSA_BYTES >> 2)
#define LITTLE_ENDIAN   0
#define BIG_ENDIAN      1

#if RSA_BITS == 1024
/*
 * Example RSA-1024 keypair, for test purposes
 */
#define RSA_N   "a9616a47156dc27eff77bf987cc938bb453783f2ac1cf12c54800edaa81ecb099038e01c5d3246b9eed85f96d2ea47f742b64059b20736a8302163ceffc1cc73715443a029d44787cc3f1ec18c08c16ae7b0acd33bc944e833b977d5a68fe1664bd96698584ffe4d7c7a8fb15fa1727a1d8e90379f56635bd7d2bfefc65c8af3"

#define RSA_E   "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010001"

#define RSA_D   "758fae831de56b9c57d6167e51061cc1261e8d0f6ed43bb4480605c94fece78180bf691566be1186d5b70a4995a4944492e20a31f735b882edbd0f184a3d8997e903a6c47b4214d95394b8cbfdd61cce5a41c2aa09977d8dfc9de16d8773eac49c33542d179de748f78141aa89ce2eb600a8909e476c2447330f91ea9987a0a1"

#define RSA_P   "DE233D4D1AD7DFC1BA5E9371E6062CF23B90F9F2B591908D51FC4E038D06D28EA337EF1B4B74883ECB41CFB618AB6E4A03E260B7AFE5CE591E63695AFE7FD5E3"

#define RSA_Q   "C3335DFF13E10EF35B147B923F17310FCCD9931480BD14CB1D3193F1FBA1A3C7424AB705386C6A7F8D269382A9488DADAE55215FD82618F09B2128F8972803B1"

#define RSA_DP  "0413db8535cfeea08cbe3db0a28b4c79e9d400728f18abf19c26a87bf233c4dbaf6d506b4cd847c3f7512ef1e5c407d33dfd02cf7c601888944138e6ddb31507"

#define RSA_DQ  "822ef3f5769096a3fe8e7e8b5ec05cdc28c6c2acdddf3ccae9c172e5e3e83d8e5acbf19bedb180a568c1dd873ad744861cca71e3b6085281c5342c5afe949541"

#define RSA_QI  "66b2419902ea79a9fba5db5df3acad6351161f5af8e355363cb17af24a1f557d20dad7894f5f7067b897fd896a6329038b036591661d9dbe1b1291afbd5c1dfe"

#define RSA_PT  "13094FFD77443DD8EAC02FEF189C6BAFACB34EDFEAF44487199CE0C77640C07494EEFB737D560ADEE3DA84F3E410CFE0AC13C6FFE3D76182ED677414BE832B145354477E9D6889243E902B979F48538524CC47FC356B9418173D8FA0DB6F10FA04E65E33F0947368D8C393953577C38F57048A3981EE1C4CAD1236044D347509"

#define RSA_CT  "669142754d8e0ba84829daa41fd8ebe1052ec069e89fe0f8559af91b7c2bac04e2b0bfd87248989738dea3a90beafd4f126164a31acf99189f1e1f7460f6730a7faf66d6208980723ddbad6b0dd06da6883aed9591e39f50c1cc4110e80a9f008da478d8ec27941b7b9c67e3a68cb4ce54a6386158f41f5b837ff15e9d738180"

#elif RSA_BITS == 256

#define RSA_N   "b250b8f95dfe81b752c93c92610ced1a" \
                "9da77c8dd0fd22eca9445b84de941b9b"

#define RSA_E   "00000000000000000000000000000000" \
                "00000000000000000000000000010001"

#define RSA_D   "191f18404186c69d9e332dae6dafd583" \
                "6b2b892b9bd6b166d74c48a5f6645379"

#define RSA_P   "CCE6F3803DED54B0779689B698365DC5"

#define RSA_Q   "DEC874AB814EEEB747E98B515D8289DF"

#define RSA_DP  "a990fab4070b8fc955be0b8b431dc2ad"

#define RSA_DQ  "cfc8fcf03d41a66a717b04c2d5c97bd7"

#define RSA_QI  "18fe4f16552854b630d74c272eb84173"

#define RSA_PT  "1980bf37e445b41c490a49cb7ba3658d" \
                "a97d0edf7e29c09d6f7723dc75d03e0d"

#define RSA_CT  "3e2f76bb13eada988de18a080063552f" \
                "b92a3df1609e8a22946339c0d46caaff"

#endif //RSA_BITS

uint8_t plaintext_byte_array[RSA_BYTES];
uint8_t ciphertext_byte_array[RSA_BYTES];
uint8_t tmp_byte_array[RSA_BYTES];
uint8_t tmp_byte_array_half_size[RSA_BYTES >> 1];


//delete later
byte_t test_array[RSA_BYTES];

/*BIGI PART - START*/
#define TMPARY_LEN 20

#ifdef HW_IMPLEMENTATION

    BUFF8 p_buff8_array;
    BUFF8 q_buff8_array;
    BUFF8 e_buff8_array;
    BUFF8 d_buff8_array;
    BUFF8 n_buff8_array;
    BUFF8 m_buff8_array;
    BUFF8 c_buff8_array;
    BUFF8 dp_buff8_array;
    BUFF8 dq_buff8_array;
    BUFF8 qi_buff8_array;

    byte_t p_io_byte_ary[RSA_BYTES];
    byte_t q_io_byte_ary[RSA_BYTES];
    byte_t e_io_byte_ary[RSA_BYTES];
    byte_t d_io_byte_ary[RSA_BYTES];
    byte_t n_io_byte_ary[RSA_BYTES];
    byte_t m_io_byte_ary[RSA_BYTES];
    byte_t c_io_byte_ary[RSA_BYTES];
    byte_t dp_io_byte_ary[RSA_BYTES];
    byte_t dq_io_byte_ary[RSA_BYTES];
    byte_t qi_io_byte_ary[RSA_BYTES]; 

    uint8_t rsa_status = 0;
    volatile unsigned int  bytes_read = 0;
#endif

word_t  plaintext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  ciphertext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t plaintext_bigi, ciphertext_bigi;

word_t tmp_arys[TMPARY_LEN * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
word_t tmp0_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp1_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp2_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp3_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp00_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp11_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp22_array[RSA_WORDS + MULT_BUFFER_WORDLEN];

bigi_t tmpary_bigi[TMPARY_LEN];
bigi_t tmp0_bigi, tmp1_bigi, tmp2_bigi, tmp3_bigi, tmp00_bigi, tmp11_bigi, tmp22_bigi;

word_t  p_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  q_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  n_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  e_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  d_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t p_bigi, q_bigi, n_bigi, e_bigi, d_bigi;

word_t  dp_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  dq_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  qi_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
bigi_t dp_bigi, dq_bigi, qi_bigi;

word_t mu_mult;
word_t index_value;

/*BIGI PART - END  */

void rsa_init(void) {
    uint16_t i;
    plaintext_bigi.ary = plaintext_array;
    plaintext_bigi.wordlen = RSA_WORDS;
    plaintext_bigi.domain = DOMAIN_NORMAL;

    ciphertext_bigi.ary = ciphertext_array;
    ciphertext_bigi.wordlen = RSA_WORDS;
    ciphertext_bigi.domain = DOMAIN_NORMAL;

    p_bigi.ary = p_array;
    p_bigi.wordlen = (RSA_WORDS >> 1);
    p_bigi.domain = DOMAIN_NORMAL;

    q_bigi.ary = q_array;
    q_bigi.wordlen = (RSA_WORDS >> 1);
    q_bigi.domain = DOMAIN_NORMAL;

    n_bigi.ary = n_array;
    n_bigi.wordlen = RSA_WORDS;
    n_bigi.domain = DOMAIN_NORMAL;

    e_bigi.ary = e_array;
    e_bigi.wordlen = RSA_WORDS;
    e_bigi.domain = DOMAIN_NORMAL;

    d_bigi.ary = d_array;
    d_bigi.wordlen = RSA_WORDS;
    d_bigi.domain = DOMAIN_NORMAL;

    dp_bigi.ary = dp_array;
    dp_bigi.wordlen = (RSA_WORDS >> 1);
    dp_bigi.domain = DOMAIN_NORMAL;

    dq_bigi.ary = dq_array;
    dq_bigi.wordlen = (RSA_WORDS >> 1);
    dq_bigi.domain = DOMAIN_NORMAL;

    qi_bigi.ary = qi_array;
    qi_bigi.wordlen = (RSA_WORDS >> 1);
    qi_bigi.domain = DOMAIN_NORMAL;

    for (i = 0; i < TMPARY_LEN; i++)
    {
        tmpary_bigi[i].ary = &tmp_arys[i * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
        tmpary_bigi[i].wordlen = RSA_WORDS;
        tmpary_bigi[i].alloclen = RSA_WORDS;
        tmpary_bigi[i].domain = DOMAIN_NORMAL;
    }

    tmp0_bigi.ary = tmp0_array;
    tmp0_bigi.wordlen = RSA_WORDS >> 1;
    tmp0_bigi.alloclen = RSA_WORDS >> 1;
    tmp0_bigi.domain = DOMAIN_NORMAL;

    tmp1_bigi.ary = tmp1_array;
    tmp1_bigi.wordlen = RSA_WORDS >> 1;
    tmp1_bigi.alloclen = RSA_WORDS >> 1;
    tmp1_bigi.domain = DOMAIN_NORMAL;

    tmp2_bigi.ary = tmp2_array;
    tmp2_bigi.wordlen = RSA_WORDS >> 1;
    tmp2_bigi.alloclen = RSA_WORDS >> 1;
    tmp2_bigi.domain = DOMAIN_NORMAL;

    tmp3_bigi.ary = tmp3_array;
    tmp3_bigi.wordlen = RSA_WORDS >> 1;
    tmp3_bigi.alloclen = RSA_WORDS >> 1;
    tmp3_bigi.domain = DOMAIN_NORMAL;

    tmp00_bigi.ary = tmp00_array;
    tmp00_bigi.wordlen = RSA_WORDS;
    tmp00_bigi.alloclen = RSA_WORDS;
    tmp00_bigi.domain = DOMAIN_NORMAL;

    tmp11_bigi.ary = tmp11_array;
    tmp11_bigi.wordlen = RSA_WORDS;
    tmp11_bigi.alloclen = RSA_WORDS;
    tmp11_bigi.domain = DOMAIN_NORMAL;

    tmp22_bigi.ary = tmp22_array;
    tmp22_bigi.wordlen = RSA_WORDS;
    tmp22_bigi.alloclen = RSA_WORDS;
    tmp22_bigi.domain = DOMAIN_NORMAL;

    /*Decoding hex to bigi structs*/
    dbg_puts_labeled("after hex decoding");
    //length in chars...
    bigi_from_hex(RSA_P,  RSA_BYTES,     &p_bigi);
    bigi_from_hex(RSA_Q,  RSA_BYTES,     &q_bigi);
    bigi_from_hex(RSA_N,  RSA_BYTES << 1,&n_bigi);
    bigi_from_hex(RSA_D,  RSA_BYTES << 1,&d_bigi);
    bigi_from_hex(RSA_E,  RSA_BYTES << 1,&e_bigi);
    bigi_from_hex(RSA_DP, RSA_BYTES,     &dp_bigi);
    bigi_from_hex(RSA_DQ, RSA_BYTES,     &dq_bigi);
    bigi_from_hex(RSA_QI, RSA_BYTES,     &qi_bigi);
    dbg_print_bigi("P", &p_bigi);
    dbg_print_bigi("Q", &q_bigi);
    dbg_print_bigi("E", &e_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("D", &d_bigi);
    dbg_print_bigi("Dp", &dp_bigi);
    dbg_print_bigi("Dq", &dq_bigi);
    dbg_print_bigi("Qinv", &qi_bigi);

#ifdef HW_IMPLEMENTATION
    p_buff8_array.len = RSA_BYTES >> 1;
    q_buff8_array.len = RSA_BYTES >> 1;
    e_buff8_array.len = RSA_BYTES;
    d_buff8_array.len = RSA_BYTES;
    n_buff8_array.len = RSA_BYTES;
    m_buff8_array.len = RSA_BYTES;
    c_buff8_array.len = RSA_BYTES;
    dp_buff8_array.len = RSA_BYTES >> 1;
    dq_buff8_array.len = RSA_BYTES >> 1;
    qi_buff8_array.len = RSA_BYTES >> 1;

    p_buff8_array.pd = (char*)&p_io_byte_ary[0];
    q_buff8_array.pd = (char*)&q_io_byte_ary[0];
    e_buff8_array.pd = (char*)&e_io_byte_ary[0];
    d_buff8_array.pd = (char*)&d_io_byte_ary[0];
    n_buff8_array.pd = (char*)&n_io_byte_ary[0];
    m_buff8_array.pd = (char*)&m_io_byte_ary[0];
    c_buff8_array.pd = (char*)&c_io_byte_ary[0];
    dp_buff8_array.pd = (char*)&dp_io_byte_ary[0];
    dq_buff8_array.pd = (char*)&dq_io_byte_ary[0];
    qi_buff8_array.pd = (char*)&qi_io_byte_ary[0];

    bigi_to_bytes(p_buff8_array.pd, RSA_BYTES >> 1, &p_bigi);
    bigi_to_bytes(q_buff8_array.pd, RSA_BYTES >> 1, &q_bigi);
    bigi_to_bytes(e_buff8_array.pd, RSA_BYTES,      &e_bigi);
    bigi_to_bytes(d_buff8_array.pd, RSA_BYTES,      &d_bigi);
    bigi_to_bytes(n_buff8_array.pd, RSA_BYTES,      &n_bigi);
    bigi_to_bytes(dp_buff8_array.pd, RSA_BYTES >> 1, &dp_bigi);
    bigi_to_bytes(dq_buff8_array.pd, RSA_BYTES >> 1, &dq_bigi);
    bigi_to_bytes(qi_buff8_array.pd, RSA_BYTES >> 1, &qi_bigi);

    dbg_puts_labeled("ARRAYS:");
    dbg_print_array("Q",    q_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("P",    p_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("E",    e_buff8_array.pd , RSA_BYTES);
    dbg_print_array("N",    n_buff8_array.pd , RSA_BYTES);
    dbg_print_array("D",    d_buff8_array.pd , RSA_BYTES);
    dbg_print_array("Dp",   dp_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Dq",   dq_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Qinv", qi_buff8_array.pd, RSA_BYTES >> 1);


    rsa_status = PKE_RET_OK;
    dbg_puts_labeled("STARTING PKE");
    pke_power(0x01);
    while(pke_busy() == 0x01);


    /*clean all slots*/
    dbg_puts_labeled("CLEANING SLOTS");
    pke_scm_clear_slot(0);
    pke_scm_clear_slot(6);
    pke_scm_clear_slot(8);
    pke_scm_clear_slot(0xA);
    pke_scm_clear_slot(0xB);
    pke_scm_clear_slot(0xC);

    rsa_status = rsa_load_key(RSA_BITS, &d_buff8_array, &n_buff8_array, &e_buff8_array, BIG_ENDIAN); 
    /*(uint16_t rsa_bit_len, const BUFF8_T *private_exponent, const BUFF8_T *public_modulus, const BUFF8_T *public_exponent, bool msbf)*/
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN LOADING RSA KEY");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_load_crt_params(RSA_BITS, &dp_buff8_array, &dq_buff8_array, &qi_buff8_array, BIG_ENDIAN);
    //uint8_t pke_rsa_load_crt_params(uint16_t rsa_bit_len, const BUFF8_T *dp, const BUFF8_T *dq, const BUFF8_T *I, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_crt_gen_params(RSA_BITS, &p_buff8_array, &q_buff8_array, &n_buff8_array, &d_buff8_array, BIG_ENDIAN);
    //(uint16_t rsa_bit_len, const BUFF8_T* p, const BUFF8_T* q, const BUFF8_T* pubmod, const BUFF8_T* prvexp, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    
#ifdef DBG
    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 8, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 8", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 6, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 6", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 0, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 0", &test_array, RSA_BYTES);


    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xA, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot A", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xB, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot B", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xC, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot C", &test_array, RSA_BYTES >> 1);
#endif /*DBG*/

    dbg_puts_labeled("KEY GENERATED");

#endif /*HW_IMPLEMENTATION*/
}




uint8_t rsa_enc(char* plaintext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, plaintext, plaintext_byte_array);
#ifdef HW_IMPLEMENTATION
    m_buff8_array.pd = (char*)&plaintext_byte_array[0];
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_encrypt(RSA_BITS, &m_buff8_array, BIG_ENDIAN);
    pke_start(0);
    while(pke_busy() == 1) asm nop;
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN ENCRYPTING");
        return 0x01;
    }

    trigger_low();

    pke_read_scm(&ciphertext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    dbg_print_array("CIPHERTEXT", &ciphertext_byte_array, RSA_BYTES);
#else
    //load plaintext to bigi_t
    bigi_from_bytes(&plaintext_bigi, plaintext_byte_array, RSA_BYTES);
    dbg_print_bigi("PLAINTEXT", &plaintext_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("E", &e_bigi);
#ifdef MONTGOMERY
    bigi_get_mont_params(&n_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi, &mu_mult);
    dbg_print_bigi("R", &tmp00_bigi);
    bigi_mod_exp_mont(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &ciphertext_bigi);
#else
    bigi_set_zero(&tmp00_bigi);
    bigi_mod_exp(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, &ciphertext_bigi);
#endif /*MONTGOMERY*/
    dbg_print_bigi("CIPHERTEXT", &ciphertext_bigi);
    bigi_to_bytes(ciphertext_byte_array, RSA_BYTES, &ciphertext_bigi);
    /*sending part*/
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, ciphertext_byte_array, RSA_BYTES);
    return 0x00;
}

uint8_t rsa_crt_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
#ifdef HW_IMPLEMENTATION
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT(IN)", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;
    
    trigger_high();

    rsa_status = rsa_crt_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;
    
    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT(OUT)", &plaintext_byte_array, RSA_BYTES);
#else
    bigi_from_bytes(&ciphertext_bigi, ciphertext_byte_array, RSA_BYTES);
    dbg_print_bigi("CIPHERTEXT(IN)", &ciphertext_bigi);
    /*decryption part*/
    trigger_high();
    //m1 = C^Dp mod P
#ifdef MONTGOMERY
    //tmp0 = C mod P
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_high();
#endif /*CP_GLITCH || M1_GLITCH*/
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_low();
#endif /*CP_GLITCH || M1_GLITCH*/
    dbg_print_bigi("Cp", &tmp1_bigi);
#ifdef CP_GLITCH
    memset(plaintext_byte_array, 0, RSA_BYTES);
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES >> 1 , &tmp1_bigi);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    trigger_low();
    return 0x00;
#endif /*CP_GLITCH*/

    //m1 = tmp0^Dp mod P
    bigi_get_mont_params(&p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi, &mu_mult);
    dbg_print_bigi("R-m1", &tmp2_bigi);
    bigi_mod_exp_mont(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_get_mont_params(&q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp3_bigi, &mu_mult);
    dbg_print_bigi("R-m2", &tmp3_bigi);
    bigi_mod_exp_mont(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#else
    //tmp0 = C mod P
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("Cp", &tmp1_bigi);
    //m1 = tmp0^Dp mod P
    bigi_mod_exp(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_mod_exp(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#endif /*MONTGOMERY*/
    //h  = (m1 - m2) * qi mod P
        // tmp2 = m1 - m2
    bigi_sub(&tmp0_bigi, &tmp1_bigi, &tmp2_bigi);
    dbg_print_bigi("M1 - M2", &tmp2_bigi);

    /* Check if result is negative number, then add P */
    index_value = 0;
    bigi_get_bit(&tmp2_bigi, ((RSA_BITS >> 1) + 1), &index_value);
    if (index_value == 1) {
        dbg_puts_labeled("A LOWER than B");
        bigi_add(&tmp2_bigi, &p_bigi, &tmp0_bigi);
        dbg_print_bigi("M1 - M2 + p", &tmp0_bigi);
    }
    else {
        dbg_puts_labeled("A GREATER than B");
        bigi_copy(&tmp0_bigi, &tmp2_bigi);
        dbg_print_bigi("M1 - M2", &tmp0_bigi);
    }

    // tmp0 * qi mod P
    bigi_mod_mult(&tmp0_bigi, &qi_bigi, &p_bigi, &tmp2_bigi);
    dbg_print_bigi("H", &tmp2_bigi);

    // m = m2 + h * Q
        // tmp00 = h * Q
    bigi_mult_fit(&tmp2_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi);
    dbg_print_bigi("H * Q", &tmp00_bigi);
    // m2 + tmp00
    bigi_add(&tmp1_bigi, &tmp00_bigi, &plaintext_bigi);
    dbg_print_bigi("PLAINTEXT(OUT)", &plaintext_bigi);
    /*sending part*/
    trigger_low();
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES, &plaintext_bigi);
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}

#ifdef HW_IMPLEMENTATION
uint8_t rsa_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;

    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT", &plaintext_byte_array, RSA_BYTES);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}
#endif /*HW_IMPLEMENTATION*/


uint8_t buf[128];
uint8_t real_crt_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_crt_dec(RSA_CT, buf);
    
#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256

    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#ifdef HW_IMPLEMENTATION
uint8_t real_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_dec(RSA_CT, buf);

    simpleserial_put('r', 48, buf);

    return ret;
}
#endif /*HW_IMPLEMENTATION*/

uint8_t real_enc(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_enc(RSA_PT, buf);

#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256
    
    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#if RSA_BITS > 512

uint8_t sig_chunk_1(uint8_t *pt)
{
     simpleserial_put('r', 48, buf + 48);
     return 0x00;
}

uint8_t sig_chunk_2(uint8_t *pt)
{
     simpleserial_put('r', RSA_BYTES - 48 * 2, buf + 48*2);
     return 0x00;
}

#endif /*RSA_BITS > 512*/