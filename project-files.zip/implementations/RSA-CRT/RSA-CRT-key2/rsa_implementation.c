/*
    This file is part of the ChipWhisperer Example Targets
    Copyright (C) 2016-2017 NewAE Technology Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "__rsa_defines.h"
#include "rsa_implementation.h"
#include "simpleserial/simpleserial.h"
#include "device_setup/cec1702_setup.h"
#include "BIGI/bigi.h"
#include "BIGI/bigi_io.h"
#include "debug.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#define RSA_BYTES (RSA_BITS  >> 3)
#define RSA_WORDS (RSA_BYTES >> 2)
#define LITTLE_ENDIAN   0
#define BIG_ENDIAN      1

#if RSA_BITS == 1024
/*
 * Example RSA-1024 keypair, for test purposes
 */
#define RSA_N   "9eab7db8579116b680287dbb381ebd361767eeb2336a2b6fa03785918a816a299bb2cd43deb3ad4edff4e6c4596d948936cd62d9d52eb247b56c2c0779b9797b55bac985266f4b9866314d547c46c201e71140bb15e573893d3702460afce8b1931f63bf61548e45a7d395817ed84f6fdd5ba402bc48789cc760028e8184fc2b"

#define RSA_E   "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010001"

#define RSA_D   "1882cd6d08b9f514443ffd0c4ae314bfa265ffcdaf7b9b322741ec744b3d2ab53ac428496fc1b9e81158b7bd6543344aee185448ea51c860a37a0e63293ea9b1518c2033ac518dfc300090fbece417c51819e4c8b68461d41a6757178e7ae79432ca5ef42542d2ad3dc2324f12a60d8dc06590da946fdb04a5e4eff5be9577a1"

#define RSA_P   "C8C269B30E8A43A49EEB02C07E8ADFB6B98857530F6E174679884D7C59C7DDE9A95070FFD570D71DB48FF86E41D27F61F29EDDC4C02AE5CFB25052C367F3EAA5"

#define RSA_Q   "CA5445872192D7A962D15783274DEBF940C731F68EAE93C70EA54306D87D9CDBAD8FCA062409F33C2B1C5E077B32EB2A97D0AB21A1A12D8A9B3DDD09F2BF228F"

#define RSA_DP  "72889f9edcc3bad5972882586999370a5b0cd2acfb579685c95e1ebebbc5cfefb77dc209e2ae4ebb8ec0b83dc6e59d70b6e735a442f1f64c28f1b455f0df7255"

#define RSA_DQ  "05c0658594dfbebfb2ee6e856ced9b22a7c3c1d8d76f8105ec95a8151ebc5b642747ea1f4890fbd81f059c6aac06e3867f70501d11a22a50415f7dd415917763"

#define RSA_QI  "37d955d22e6c3857394d5bad78ea15bbcf5e72b7a1a22343bcc2c5b62d74c2dfed8a6e31a4ce50b2cba4ab9461b452e342f5de625d52faf2a7845458bb7dbbd9"

#define RSA_PT  "13094FFD77443DD8EAC02FEF189C6BAFACB34EDFEAF44487199CE0C77640C07494EEFB737D560ADEE3DA84F3E410CFE0AC13C6FFE3D76182ED677414BE832B145354477E9D6889243E902B979F48538524CC47FC356B9418173D8FA0DB6F10FA04E65E33F0947368D8C393953577C38F57048A3981EE1C4CAD1236044D347509"

#define RSA_CT  "3b2288af3257735f8124b95cd410ff8beafa8c3969dcf1df8c92f6db59356c4621d6dc406dc17317657492a7e00d5d51ea81a4722dfe459b48315b8a7dc75a4cffb9835e9fa2cef6c903f2b294f486d5655dd35a407f8dd43dc1e3389fdcdf20b850a794fc845b616113ca9b5f8dff8df22b4c4f90469476fe800dcfbbb111a1"

#elif RSA_BITS == 256

#define RSA_N   "b250b8f95dfe81b752c93c92610ced1a" \
                "9da77c8dd0fd22eca9445b84de941b9b"

#define RSA_E   "00000000000000000000000000000000" \
                "00000000000000000000000000010001"

#define RSA_D   "191f18404186c69d9e332dae6dafd583" \
                "6b2b892b9bd6b166d74c48a5f6645379"

#define RSA_P   "CCE6F3803DED54B0779689B698365DC5"

#define RSA_Q   "DEC874AB814EEEB747E98B515D8289DF"

#define RSA_DP  "a990fab4070b8fc955be0b8b431dc2ad"

#define RSA_DQ  "cfc8fcf03d41a66a717b04c2d5c97bd7"

#define RSA_QI  "18fe4f16552854b630d74c272eb84173"

#define RSA_PT  "1980bf37e445b41c490a49cb7ba3658d" \
                "a97d0edf7e29c09d6f7723dc75d03e0d"

#define RSA_CT  "3e2f76bb13eada988de18a080063552f" \
                "b92a3df1609e8a22946339c0d46caaff"

#endif //RSA_BITS

uint8_t plaintext_byte_array[RSA_BYTES];
uint8_t ciphertext_byte_array[RSA_BYTES];
uint8_t tmp_byte_array[RSA_BYTES];
uint8_t tmp_byte_array_half_size[RSA_BYTES >> 1];


//delete later
byte_t test_array[RSA_BYTES];

/*BIGI PART - START*/
#define TMPARY_LEN 20

#ifdef HW_IMPLEMENTATION

    BUFF8 p_buff8_array;
    BUFF8 q_buff8_array;
    BUFF8 e_buff8_array;
    BUFF8 d_buff8_array;
    BUFF8 n_buff8_array;
    BUFF8 m_buff8_array;
    BUFF8 c_buff8_array;
    BUFF8 dp_buff8_array;
    BUFF8 dq_buff8_array;
    BUFF8 qi_buff8_array;

    byte_t p_io_byte_ary[RSA_BYTES];
    byte_t q_io_byte_ary[RSA_BYTES];
    byte_t e_io_byte_ary[RSA_BYTES];
    byte_t d_io_byte_ary[RSA_BYTES];
    byte_t n_io_byte_ary[RSA_BYTES];
    byte_t m_io_byte_ary[RSA_BYTES];
    byte_t c_io_byte_ary[RSA_BYTES];
    byte_t dp_io_byte_ary[RSA_BYTES];
    byte_t dq_io_byte_ary[RSA_BYTES];
    byte_t qi_io_byte_ary[RSA_BYTES]; 

    uint8_t rsa_status = 0;
    volatile unsigned int  bytes_read = 0;
#endif

word_t  plaintext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  ciphertext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t plaintext_bigi, ciphertext_bigi;

word_t tmp_arys[TMPARY_LEN * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
word_t tmp0_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp1_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp2_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp3_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp00_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp11_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp22_array[RSA_WORDS + MULT_BUFFER_WORDLEN];

bigi_t tmpary_bigi[TMPARY_LEN];
bigi_t tmp0_bigi, tmp1_bigi, tmp2_bigi, tmp3_bigi, tmp00_bigi, tmp11_bigi, tmp22_bigi;

word_t  p_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  q_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  n_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  e_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  d_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t p_bigi, q_bigi, n_bigi, e_bigi, d_bigi;

word_t  dp_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  dq_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  qi_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
bigi_t dp_bigi, dq_bigi, qi_bigi;

word_t mu_mult;
word_t index_value;

/*BIGI PART - END  */

void rsa_init(void) {
    uint16_t i;
    plaintext_bigi.ary = plaintext_array;
    plaintext_bigi.wordlen = RSA_WORDS;
    plaintext_bigi.domain = DOMAIN_NORMAL;

    ciphertext_bigi.ary = ciphertext_array;
    ciphertext_bigi.wordlen = RSA_WORDS;
    ciphertext_bigi.domain = DOMAIN_NORMAL;

    p_bigi.ary = p_array;
    p_bigi.wordlen = (RSA_WORDS >> 1);
    p_bigi.domain = DOMAIN_NORMAL;

    q_bigi.ary = q_array;
    q_bigi.wordlen = (RSA_WORDS >> 1);
    q_bigi.domain = DOMAIN_NORMAL;

    n_bigi.ary = n_array;
    n_bigi.wordlen = RSA_WORDS;
    n_bigi.domain = DOMAIN_NORMAL;

    e_bigi.ary = e_array;
    e_bigi.wordlen = RSA_WORDS;
    e_bigi.domain = DOMAIN_NORMAL;

    d_bigi.ary = d_array;
    d_bigi.wordlen = RSA_WORDS;
    d_bigi.domain = DOMAIN_NORMAL;

    dp_bigi.ary = dp_array;
    dp_bigi.wordlen = (RSA_WORDS >> 1);
    dp_bigi.domain = DOMAIN_NORMAL;

    dq_bigi.ary = dq_array;
    dq_bigi.wordlen = (RSA_WORDS >> 1);
    dq_bigi.domain = DOMAIN_NORMAL;

    qi_bigi.ary = qi_array;
    qi_bigi.wordlen = (RSA_WORDS >> 1);
    qi_bigi.domain = DOMAIN_NORMAL;

    for (i = 0; i < TMPARY_LEN; i++)
    {
        tmpary_bigi[i].ary = &tmp_arys[i * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
        tmpary_bigi[i].wordlen = RSA_WORDS;
        tmpary_bigi[i].alloclen = RSA_WORDS;
        tmpary_bigi[i].domain = DOMAIN_NORMAL;
    }

    tmp0_bigi.ary = tmp0_array;
    tmp0_bigi.wordlen = RSA_WORDS >> 1;
    tmp0_bigi.alloclen = RSA_WORDS >> 1;
    tmp0_bigi.domain = DOMAIN_NORMAL;

    tmp1_bigi.ary = tmp1_array;
    tmp1_bigi.wordlen = RSA_WORDS >> 1;
    tmp1_bigi.alloclen = RSA_WORDS >> 1;
    tmp1_bigi.domain = DOMAIN_NORMAL;

    tmp2_bigi.ary = tmp2_array;
    tmp2_bigi.wordlen = RSA_WORDS >> 1;
    tmp2_bigi.alloclen = RSA_WORDS >> 1;
    tmp2_bigi.domain = DOMAIN_NORMAL;

    tmp3_bigi.ary = tmp3_array;
    tmp3_bigi.wordlen = RSA_WORDS >> 1;
    tmp3_bigi.alloclen = RSA_WORDS >> 1;
    tmp3_bigi.domain = DOMAIN_NORMAL;

    tmp00_bigi.ary = tmp00_array;
    tmp00_bigi.wordlen = RSA_WORDS;
    tmp00_bigi.alloclen = RSA_WORDS;
    tmp00_bigi.domain = DOMAIN_NORMAL;

    tmp11_bigi.ary = tmp11_array;
    tmp11_bigi.wordlen = RSA_WORDS;
    tmp11_bigi.alloclen = RSA_WORDS;
    tmp11_bigi.domain = DOMAIN_NORMAL;

    tmp22_bigi.ary = tmp22_array;
    tmp22_bigi.wordlen = RSA_WORDS;
    tmp22_bigi.alloclen = RSA_WORDS;
    tmp22_bigi.domain = DOMAIN_NORMAL;

    /*Decoding hex to bigi structs*/
    dbg_puts_labeled("after hex decoding");
    //length in chars...
    bigi_from_hex(RSA_P,  RSA_BYTES,     &p_bigi);
    bigi_from_hex(RSA_Q,  RSA_BYTES,     &q_bigi);
    bigi_from_hex(RSA_N,  RSA_BYTES << 1,&n_bigi);
    bigi_from_hex(RSA_D,  RSA_BYTES << 1,&d_bigi);
    bigi_from_hex(RSA_E,  RSA_BYTES << 1,&e_bigi);
    bigi_from_hex(RSA_DP, RSA_BYTES,     &dp_bigi);
    bigi_from_hex(RSA_DQ, RSA_BYTES,     &dq_bigi);
    bigi_from_hex(RSA_QI, RSA_BYTES,     &qi_bigi);
    dbg_print_bigi("P", &p_bigi);
    dbg_print_bigi("Q", &q_bigi);
    dbg_print_bigi("E", &e_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("D", &d_bigi);
    dbg_print_bigi("Dp", &dp_bigi);
    dbg_print_bigi("Dq", &dq_bigi);
    dbg_print_bigi("Qinv", &qi_bigi);

#ifdef HW_IMPLEMENTATION
    p_buff8_array.len = RSA_BYTES >> 1;
    q_buff8_array.len = RSA_BYTES >> 1;
    e_buff8_array.len = RSA_BYTES;
    d_buff8_array.len = RSA_BYTES;
    n_buff8_array.len = RSA_BYTES;
    m_buff8_array.len = RSA_BYTES;
    c_buff8_array.len = RSA_BYTES;
    dp_buff8_array.len = RSA_BYTES >> 1;
    dq_buff8_array.len = RSA_BYTES >> 1;
    qi_buff8_array.len = RSA_BYTES >> 1;

    p_buff8_array.pd = (char*)&p_io_byte_ary[0];
    q_buff8_array.pd = (char*)&q_io_byte_ary[0];
    e_buff8_array.pd = (char*)&e_io_byte_ary[0];
    d_buff8_array.pd = (char*)&d_io_byte_ary[0];
    n_buff8_array.pd = (char*)&n_io_byte_ary[0];
    m_buff8_array.pd = (char*)&m_io_byte_ary[0];
    c_buff8_array.pd = (char*)&c_io_byte_ary[0];
    dp_buff8_array.pd = (char*)&dp_io_byte_ary[0];
    dq_buff8_array.pd = (char*)&dq_io_byte_ary[0];
    qi_buff8_array.pd = (char*)&qi_io_byte_ary[0];

    bigi_to_bytes(p_buff8_array.pd, RSA_BYTES >> 1, &p_bigi);
    bigi_to_bytes(q_buff8_array.pd, RSA_BYTES >> 1, &q_bigi);
    bigi_to_bytes(e_buff8_array.pd, RSA_BYTES,      &e_bigi);
    bigi_to_bytes(d_buff8_array.pd, RSA_BYTES,      &d_bigi);
    bigi_to_bytes(n_buff8_array.pd, RSA_BYTES,      &n_bigi);
    bigi_to_bytes(dp_buff8_array.pd, RSA_BYTES >> 1, &dp_bigi);
    bigi_to_bytes(dq_buff8_array.pd, RSA_BYTES >> 1, &dq_bigi);
    bigi_to_bytes(qi_buff8_array.pd, RSA_BYTES >> 1, &qi_bigi);

    dbg_puts_labeled("ARRAYS:");
    dbg_print_array("Q",    q_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("P",    p_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("E",    e_buff8_array.pd , RSA_BYTES);
    dbg_print_array("N",    n_buff8_array.pd , RSA_BYTES);
    dbg_print_array("D",    d_buff8_array.pd , RSA_BYTES);
    dbg_print_array("Dp",   dp_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Dq",   dq_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Qinv", qi_buff8_array.pd, RSA_BYTES >> 1);


    rsa_status = PKE_RET_OK;
    dbg_puts_labeled("STARTING PKE");
    pke_power(0x01);
    while(pke_busy() == 0x01);


    /*clean all slots*/
    dbg_puts_labeled("CLEANING SLOTS");
    pke_scm_clear_slot(0);
    pke_scm_clear_slot(6);
    pke_scm_clear_slot(8);
    pke_scm_clear_slot(0xA);
    pke_scm_clear_slot(0xB);
    pke_scm_clear_slot(0xC);

    rsa_status = rsa_load_key(RSA_BITS, &d_buff8_array, &n_buff8_array, &e_buff8_array, BIG_ENDIAN); 
    /*(uint16_t rsa_bit_len, const BUFF8_T *private_exponent, const BUFF8_T *public_modulus, const BUFF8_T *public_exponent, bool msbf)*/
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN LOADING RSA KEY");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_load_crt_params(RSA_BITS, &dp_buff8_array, &dq_buff8_array, &qi_buff8_array, BIG_ENDIAN);
    //uint8_t pke_rsa_load_crt_params(uint16_t rsa_bit_len, const BUFF8_T *dp, const BUFF8_T *dq, const BUFF8_T *I, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_crt_gen_params(RSA_BITS, &p_buff8_array, &q_buff8_array, &n_buff8_array, &d_buff8_array, BIG_ENDIAN);
    //(uint16_t rsa_bit_len, const BUFF8_T* p, const BUFF8_T* q, const BUFF8_T* pubmod, const BUFF8_T* prvexp, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    
#ifdef DBG
    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 8, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 8", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 6, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 6", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 0, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 0", &test_array, RSA_BYTES);


    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xA, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot A", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xB, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot B", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xC, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot C", &test_array, RSA_BYTES >> 1);
#endif /*DBG*/

    dbg_puts_labeled("KEY GENERATED");

#endif /*HW_IMPLEMENTATION*/
}




uint8_t rsa_enc(char* plaintext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, plaintext, plaintext_byte_array);
#ifdef HW_IMPLEMENTATION
    m_buff8_array.pd = (char*)&plaintext_byte_array[0];
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_encrypt(RSA_BITS, &m_buff8_array, BIG_ENDIAN);
    pke_start(0);
    while(pke_busy() == 1) asm nop;
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN ENCRYPTING");
        return 0x01;
    }

    trigger_low();

    pke_read_scm(&ciphertext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    dbg_print_array("CIPHERTEXT", &ciphertext_byte_array, RSA_BYTES);
#else
    //load plaintext to bigi_t
    bigi_from_bytes(&plaintext_bigi, plaintext_byte_array, RSA_BYTES);
    dbg_print_bigi("PLAINTEXT", &plaintext_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("E", &e_bigi);
#ifdef MONTGOMERY
    bigi_get_mont_params(&n_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi, &mu_mult);
    dbg_print_bigi("R", &tmp00_bigi);
    bigi_mod_exp_mont(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &ciphertext_bigi);
#else
    bigi_set_zero(&tmp00_bigi);
    bigi_mod_exp(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, &ciphertext_bigi);
#endif /*MONTGOMERY*/
    dbg_print_bigi("CIPHERTEXT", &ciphertext_bigi);
    bigi_to_bytes(ciphertext_byte_array, RSA_BYTES, &ciphertext_bigi);
    /*sending part*/
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, ciphertext_byte_array, RSA_BYTES);
    return 0x00;
}

uint8_t rsa_crt_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
#ifdef HW_IMPLEMENTATION
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT(IN)", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;
    
    trigger_high();

    rsa_status = rsa_crt_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;
    
    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT(OUT)", &plaintext_byte_array, RSA_BYTES);
#else
    bigi_from_bytes(&ciphertext_bigi, ciphertext_byte_array, RSA_BYTES);
    dbg_print_bigi("CIPHERTEXT(IN)", &ciphertext_bigi);
    /*decryption part*/
    trigger_high();
    //m1 = C^Dp mod P
#ifdef MONTGOMERY
    //tmp0 = C mod P
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_high();
#endif /*CP_GLITCH || M1_GLITCH*/
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_low();
#endif /*CP_GLITCH || M1_GLITCH*/
    dbg_print_bigi("Cp", &tmp1_bigi);
#ifdef CP_GLITCH
    memset(plaintext_byte_array, 0, RSA_BYTES);
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES >> 1 , &tmp1_bigi);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    trigger_low();
    return 0x00;
#endif /*CP_GLITCH*/

    //m1 = tmp0^Dp mod P
    bigi_get_mont_params(&p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi, &mu_mult);
    dbg_print_bigi("R-m1", &tmp2_bigi);
    bigi_mod_exp_mont(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_get_mont_params(&q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp3_bigi, &mu_mult);
    dbg_print_bigi("R-m2", &tmp3_bigi);
    bigi_mod_exp_mont(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#else
    //tmp0 = C mod P
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("Cp", &tmp1_bigi);
    //m1 = tmp0^Dp mod P
    bigi_mod_exp(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_mod_exp(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#endif /*MONTGOMERY*/
    //h  = (m1 - m2) * qi mod P
        // tmp2 = m1 - m2
    bigi_sub(&tmp0_bigi, &tmp1_bigi, &tmp2_bigi);
    dbg_print_bigi("M1 - M2", &tmp2_bigi);

    /* Check if result is negative number, then add P */
    index_value = 0;
    bigi_get_bit(&tmp2_bigi, ((RSA_BITS >> 1) + 1), &index_value);
    if (index_value == 1) {
        dbg_puts_labeled("A LOWER than B");
        bigi_add(&tmp2_bigi, &p_bigi, &tmp0_bigi);
        dbg_print_bigi("M1 - M2 + p", &tmp0_bigi);
    }
    else {
        dbg_puts_labeled("A GREATER than B");
        bigi_copy(&tmp0_bigi, &tmp2_bigi);
        dbg_print_bigi("M1 - M2", &tmp0_bigi);
    }

    // tmp0 * qi mod P
    bigi_mod_mult(&tmp0_bigi, &qi_bigi, &p_bigi, &tmp2_bigi);
    dbg_print_bigi("H", &tmp2_bigi);

    // m = m2 + h * Q
        // tmp00 = h * Q
    bigi_mult_fit(&tmp2_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi);
    dbg_print_bigi("H * Q", &tmp00_bigi);
    // m2 + tmp00
    bigi_add(&tmp1_bigi, &tmp00_bigi, &plaintext_bigi);
    dbg_print_bigi("PLAINTEXT(OUT)", &plaintext_bigi);
    /*sending part*/
    trigger_low();
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES, &plaintext_bigi);
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}

#ifdef HW_IMPLEMENTATION
uint8_t rsa_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;

    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT", &plaintext_byte_array, RSA_BYTES);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}
#endif /*HW_IMPLEMENTATION*/


uint8_t buf[128];
uint8_t real_crt_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_crt_dec(RSA_CT, buf);
    
#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256

    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#ifdef HW_IMPLEMENTATION
uint8_t real_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_dec(RSA_CT, buf);

    simpleserial_put('r', 48, buf);

    return ret;
}
#endif /*HW_IMPLEMENTATION*/

uint8_t real_enc(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_enc(RSA_PT, buf);

#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256
    
    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#if RSA_BITS > 512

uint8_t sig_chunk_1(uint8_t *pt)
{
     simpleserial_put('r', 48, buf + 48);
     return 0x00;
}

uint8_t sig_chunk_2(uint8_t *pt)
{
     simpleserial_put('r', RSA_BYTES - 48 * 2, buf + 48*2);
     return 0x00;
}

#endif /*RSA_BITS > 512*/