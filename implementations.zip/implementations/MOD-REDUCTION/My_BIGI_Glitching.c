/*
    This file is part of the ChipWhisperer Example Targets
    Copyright (C) 2012-2020 NewAE Technology Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <stdint.h>
#include <stdlib.h>

#include "device_setup/cec1702_setup.h"
#include "simpleserial/simpleserial.h"
#include "bigi/bigi.h"
#include "bigi/bigi_io.h"
#include "debug.h"

//#define RETURN_BIGI_RESULT

#define BIGI_128BIT       "24BF6185468786FDD303083D25E64EFC"
#define BIGI_MOD_64BIT    "C36D0EB7FCD28522"
#define BIGI_RESULT_64BIT "3998712d126c9df4"
#define TMPARY_LEN        10
#define TMPARY_ARRAY_LEN  4
/*Declarations*/

uint8_t tmp_byte_array[16];
uint8_t tmp_byte_array_half_size[8];

cmp_t compare_result;
word_t  mod_array[2 + MULT_BUFFER_WORDLEN];
word_t  input_array[4 + MULT_BUFFER_WORDLEN];
word_t  ouput_array[2 + MULT_BUFFER_WORDLEN];
word_t  result_array[2 + MULT_BUFFER_WORDLEN];
bigi_t mod_bigi, input_bigi, output_bigi, result_bigi;

word_t tmp_arys[TMPARY_LEN * (TMPARY_ARRAY_LEN + MULT_BUFFER_WORDLEN)];
bigi_t tmpary_bigi[TMPARY_LEN];

int my_hex_decode(int len, char* ascii_buf, uint8_t* data_buf)
{
    int i = 0;
    for (i = 0; i < len; i++)
    {
        char n_hi = ascii_buf[2 * i];
        char n_lo = ascii_buf[2 * i + 1];
        if (n_lo >= '0' && n_lo <= '9')
            data_buf[i] = n_lo - '0';
        else if (n_lo >= 'A' && n_lo <= 'F')
            data_buf[i] = n_lo - 'A' + 10;
        else if (n_lo >= 'a' && n_lo <= 'f')
            data_buf[i] = n_lo - 'a' + 10;
        else
            return 1;

        if (n_hi >= '0' && n_hi <= '9')
            data_buf[i] |= (n_hi - '0') << 4;
        else if (n_hi >= 'A' && n_hi <= 'F')
            data_buf[i] |= (n_hi - 'A' + 10) << 4;
        else if (n_hi >= 'a' && n_hi <= 'f')
            data_buf[i] |= (n_hi - 'a' + 10) << 4;
        else
            return 1;
}
    return 0;
}

uint8_t glitch_bigi_modRed_128_to_64bit(uint8_t* in)
{
    int i;
#ifdef RETURN_BIGI_RESULT
    uint8_t output[8];
#else
    uint8_t ok;
#endif
    /*BIGI init*/
    mod_bigi.ary = mod_array;
    mod_bigi.wordlen = 2;
    mod_bigi.domain = DOMAIN_NORMAL;

    input_bigi.ary = input_array;
    input_bigi.wordlen = 4;
    input_bigi.domain = DOMAIN_NORMAL;

    output_bigi.ary = ouput_array;
    output_bigi.wordlen = 2;
    output_bigi.domain = DOMAIN_NORMAL;

    result_bigi.ary = result_array;
    result_bigi.wordlen = 2;
    result_bigi.domain = DOMAIN_NORMAL;

    for (i = 0; i < TMPARY_LEN; i++)
    {
        tmpary_bigi[i].ary = &tmp_arys[i * (TMPARY_ARRAY_LEN + MULT_BUFFER_WORDLEN)];
        tmpary_bigi[i].wordlen = TMPARY_ARRAY_LEN;
        tmpary_bigi[i].alloclen = TMPARY_ARRAY_LEN;
        tmpary_bigi[i].domain = DOMAIN_NORMAL;
    }

    /*Fill with real values*/
    my_hex_decode(16, BIGI_128BIT, tmp_byte_array);
    bigi_from_bytes(&input_bigi, tmp_byte_array, 16);
    
    my_hex_decode(8, BIGI_MOD_64BIT, tmp_byte_array_half_size);
    bigi_from_bytes(&mod_bigi, tmp_byte_array_half_size, 8);

    my_hex_decode(8, BIGI_RESULT_64BIT, tmp_byte_array_half_size);
    bigi_from_bytes(&result_bigi, tmp_byte_array_half_size, 8);
    
    dbg_print_bigi("IN ", &input_bigi);
    dbg_print_bigi("MOD", &mod_bigi);  
    dbg_print_bigi("RES", &result_bigi);

    /*Real computation*/
    trigger_high();
    bigi_mod_red(&input_bigi, &mod_bigi, &tmpary_bigi[0], TMPARY_LEN, &output_bigi);
    trigger_low();
    dbg_print_bigi("OUT", &output_bigi);

#ifdef RETURN_BIGI_RESULT
    /*Sending whole result*/
    bigi_to_bytes(output, 8, &output_bigi);
    simpleserial_put('r', 8, (uint8_t*)&output);
    return 0x00;
#else
    /*Sending only a result*/
    bigi_cmp(&result_bigi, &output_bigi, &compare_result);
    ok = (compare_result != CMP_EQUAL) ? 0x01 : 0x00;
    simpleserial_put('r', 1, (uint8_t*)&ok);
    return 0x00;
#endif //RETURN_BIGI_RESULT
}


uint8_t glitch_loop(uint8_t* in)
{
    volatile uint16_t i, j;
    volatile uint32_t cnt;
    cnt = 0;
    trigger_high();
    for(i=0; i<50; i++){
        for(j=0; j<50; j++){
            cnt++;
        }
    }
    trigger_low();
    simpleserial_put('r', 4, (uint8_t*)&cnt);
    return (cnt != 2500);
}

int main(void)
{
    platform_init();
    init_uart();
    trigger_setup();

    simpleserial_init();
    simpleserial_addcmd('g', 0, glitch_loop);
    
    simpleserial_addcmd('b', 0, glitch_bigi_modRed_128_to_64bit);

    while(1)
        simpleserial_get();
}