#ifndef RSA_IMPLEMENTATION_H
#define RSA_IMPLEMENTATION_H

#include <stdint.h>

//RSA_BITS can be set to 256 or 1024
#define RSA_BITS 1024

/************************************/
/*SWITCH FOR ANABELING  HW ACCELATOR*/
#define HW_IMPLEMENTATION
/************************************/

#ifdef HW_IMPLEMENTATION
#define RSA_BITS 1024

#else
/************************************/
/*SWITCH FOR USING  MONTGOMERY DOMAIN*/
/*    ONLY FOR PURELY SW VERSION    */
    #define MONTGOMERY
/************************************/


/************************************/
/*    SWITCHES FOR GLITCHING        */ 
/*!Works only with  macro MONTGOMERY!*/
/*    ONLY FOR PURELY SW VERSION    */
#//define CP_GLITCH
/*        FOR SW and HW RSA         */
#define M1_GLITCH
/************************************/
#endif /*HW_IMPLEMENTATION*/

void rsa_init(void);

#ifdef HW_IMPLEMENTATION
uint8_t real_dec(uint8_t * pt);
#endif /*HW_IMPLEMENTATION*/
uint8_t real_crt_dec(uint8_t *pt);
uint8_t real_enc(uint8_t * pt);


#if RSA_BITS > 512
uint8_t sig_chunk_1(uint8_t* pt);
uint8_t sig_chunk_2(uint8_t* pt);
#endif //RSA_BITS > 512

#endif //RSA_IMPLEMENTATION_H