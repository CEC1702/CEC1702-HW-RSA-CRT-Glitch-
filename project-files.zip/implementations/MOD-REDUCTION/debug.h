#ifndef DEBUG_H
#define DEBUG_H

#include "BIGI/bigi.h"

//#define DBG

/*
 * Helper functions for easier debbuging
 */

void dbg_putch (const char c);

void dbg_puts (const char * str);

void dbg_putch_labeled (const char c);

void dbg_puts_labeled (const char * str);

void print_puts_plain (const char* str);

void dbg_print_bigi (const char * tag, const bigi_t* const bigi_number);

void dbg_print_array(const char* tag, const uint8_t* const arr, const uint16_t size);

#endif //DEBUG_H