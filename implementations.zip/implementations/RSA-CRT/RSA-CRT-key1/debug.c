#include "debug.h"
#include "device_setup/cec1702_setup.h"
#include "BIGI/bigi.h"
#include "BIGI/bigi_io.h"

#ifdef DBG

void put_label(void) {
    putch('\n');
    putch('D');
    putch('B');
    putch('G');
    putch(':');
}

void putstr(const char* text) {
    int i = 0;
    while (text[i] != 0) {
        putch(text[i]);
        ++i;
    }
}

void dbg_putch (const char c) {
    putch(c);
}

void dbg_puts (const char * str) {
    putch('\n');
    putstr(str);
    putch('\n');
}

void dbg_putch_labeled (const char c) {
    put_label();
    putch(c);
    putch('\n');
}

void dbg_puts_labeled (const char * str) {
    put_label();
    putstr(str);
    putch('\n');
}

void print_puts_plain(const char* str) {
    putstr(str);
}

void dbg_print_bigi(const char* tag, const bigi_t* const bigi_number) {
    putstr(tag);
    putch(':');
    putch(' ');
    bigi_print(bigi_number);
    putch('\n');
}

void dbg_print_array(const char* tag, const uint8_t* const arr, const uint16_t size) {
    uint16_t i = 0;
    char buff_num[3];
    putstr(tag);
    putch(':');
    putch(' ');
    for (i; i < size ; ++i) {
        sprintf(buff_num, "%02x", arr[i]);
        putstr(buff_num);
    }
    putch('\n');
}
#else

void dbg_putch(const char c) {}

void dbg_puts(const char* str) {}

void dbg_putch_labeled(const char c) {}

void dbg_puts_labeled(const char* str) {}

void print_puts_plain(const char* str) {}

void dbg_print_bigi(const char* tag, const bigi_t* const bigi_number) {}

void dbg_print_array(const char* tag, const uint8_t* const arr, const uint16_t size) {}


#endif