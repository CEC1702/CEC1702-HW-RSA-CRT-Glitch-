/*
    This file is part of the ChipWhisperer Example Targets
    Copyright (C) 2016-2017 NewAE Technology Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "__rsa_defines.h"
#include "rsa_implementation.h"
#include "simpleserial/simpleserial.h"
#include "device_setup/cec1702_setup.h"
#include "BIGI/bigi.h"
#include "BIGI/bigi_io.h"
#include "debug.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#define RSA_BYTES (RSA_BITS  >> 3)
#define RSA_WORDS (RSA_BYTES >> 2)
#define LITTLE_ENDIAN   0
#define BIG_ENDIAN      1

#if RSA_BITS == 1024
/*
 * Example RSA-1024 keypair, for test purposes
 */
#define RSA_N   "9292758453063D803DD603D5E777D788" \
                "8ED1D5BF35786190FA2F23EBC0848AEA" \
                "DDA92CA6C3D80B32C4D109BE0F36D6AE" \
                "7130B9CED7ACDF54CFC7555AC14EEBAB" \
                "93A89813FBF3C4F8066D2D800F7C38A8" \
                "1AE31942917403FF4946B0A83D3D3E05" \
                "EE57C6F5F5606FB5D4BC6CD34EE0801A" \
                "5E94BB77B07507233A0BC7BAC8F90F79"

#define RSA_E   "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000000000" \
                "00000000000000000000000000010001"

#define RSA_D   "24BF6185468786FDD303083D25E64EFC" \
                "66CA472BC44D253102F8B4A9D3BFA750" \
                "91386C0077937FE33FA3252D28855837" \
                "AE1B484A8A9A45F7EE8C0C634F99E8CD" \
                "DF79C5CE07EE72C7F123142198164234" \
                "CABB724CF78B8173B9F880FC86322407" \
                "AF1FEDFDDE2BEB674CA15F3E81A1521E" \
                "071513A1E85B5DFA031F21ECAE91A34D"

#define RSA_P   "C36D0EB7FCD285223CFB5AABA5BDA3D8" \
                "2C01CAD19EA484A87EA4377637E75500" \
                "FCB2005C5C7DD6EC4AC023CDA285D796" \
                "C3D9E75E1EFC42488BB4F1D13AC30A57"

#define RSA_Q   "C000DF51A7C77AE8D7C7370C1FF55B69" \
                "E211C2B9E5DB1ED0BF61D0D9899620F4" \
                "910E4168387E3C30AA1E00C339A79508" \
                "8452DD96A9A5EA5D9DCA68DA636032AF"

#define RSA_DP  "C1ACF567564274FB07A0BBAD5D26E298" \
                "3C94D22288ACD763FD8E5600ED4A702D" \
                "F84198A5F06C2E72236AE490C93F07F8" \
                "3CC559CD27BC2D1CA488811730BB5725"

#define RSA_DQ  "4959CBF6F8FEF750AEE6977C155579C7" \
                "D8AAEA56749EA28623272E4F7D0592AF" \
                "7C1F1313CAC9471B5C523BFE592F517B" \
                "407A1BD76C164B93DA2D32A383E58357"

#define RSA_QI  "9AE7FBC99546432DF71896FC239EADAE" \
                "F38D18D2B2F0E2DD275AA977E2BF4411" \
                "F5A3B2A5D33605AEBBCCBA7FEB9F2D2F" \
                "A74206CEC169D74BF5A8C50D6F48EA08"

#define RSA_PT  "11144444444444444444444444444444" \
                "44444444444444444444444444444444" \
                "44444444444444444444444444444444" \
                "44444444444444444444444444123456" \
                "11144444444444444444444444444444" \
                "44444444444444444444444444444444" \
                "44444444444444444444444444444444" \
                "44444444444444444444444444123456"

#define RSA_CT  "1701e0c7306e79a3fbef9c26b12c072b" \
                "2f33b613941978404067e9484859eba1" \
                "8669e1003a61e05b91f106d16f749b52" \
                "afdc5b66ccf2faa75d630694dd2b425f" \
                "6bcd8d896bd1f7f15f65dd64dcaa17f1" \
                "f3b826ec78d66d452132cae92d35b642" \
                "146acdd4b7cf218a42b57122149cd98a" \
                "13c9018cd99ecde00a699c5d6cf59666"

#elif RSA_BITS == 256

#define RSA_N   "b250b8f95dfe81b752c93c92610ced1a" \
                "9da77c8dd0fd22eca9445b84de941b9b"

#define RSA_E   "00000000000000000000000000000000" \
                "00000000000000000000000000010001"

#define RSA_D   "191f18404186c69d9e332dae6dafd583" \
                "6b2b892b9bd6b166d74c48a5f6645379"

#define RSA_P   "CCE6F3803DED54B0779689B698365DC5"

#define RSA_Q   "DEC874AB814EEEB747E98B515D8289DF"

#define RSA_DP  "a990fab4070b8fc955be0b8b431dc2ad"

#define RSA_DQ  "cfc8fcf03d41a66a717b04c2d5c97bd7"

#define RSA_QI  "18fe4f16552854b630d74c272eb84173"

#define RSA_PT  "1980bf37e445b41c490a49cb7ba3658d" \
                "a97d0edf7e29c09d6f7723dc75d03e0d"

#define RSA_CT  "3e2f76bb13eada988de18a080063552f" \
                "b92a3df1609e8a22946339c0d46caaff"

#endif //RSA_BITS

uint8_t plaintext_byte_array[RSA_BYTES];
uint8_t ciphertext_byte_array[RSA_BYTES];
uint8_t tmp_byte_array[RSA_BYTES];
uint8_t tmp_byte_array_half_size[RSA_BYTES >> 1];


//delete later
byte_t test_array[RSA_BYTES];

/*BIGI PART - START*/
#define TMPARY_LEN 20

#ifdef HW_IMPLEMENTATION

    BUFF8 p_buff8_array;
    BUFF8 q_buff8_array;
    BUFF8 e_buff8_array;
    BUFF8 d_buff8_array;
    BUFF8 n_buff8_array;
    BUFF8 m_buff8_array;
    BUFF8 c_buff8_array;
    BUFF8 dp_buff8_array;
    BUFF8 dq_buff8_array;
    BUFF8 qi_buff8_array;

    byte_t p_io_byte_ary[RSA_BYTES];
    byte_t q_io_byte_ary[RSA_BYTES];
    byte_t e_io_byte_ary[RSA_BYTES];
    byte_t d_io_byte_ary[RSA_BYTES];
    byte_t n_io_byte_ary[RSA_BYTES];
    byte_t m_io_byte_ary[RSA_BYTES];
    byte_t c_io_byte_ary[RSA_BYTES];
    byte_t dp_io_byte_ary[RSA_BYTES];
    byte_t dq_io_byte_ary[RSA_BYTES];
    byte_t qi_io_byte_ary[RSA_BYTES]; 

    uint8_t rsa_status = 0;
    volatile unsigned int  bytes_read = 0;
#endif

word_t  plaintext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  ciphertext_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t plaintext_bigi, ciphertext_bigi;

word_t tmp_arys[TMPARY_LEN * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
word_t tmp0_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp1_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp2_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp3_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t tmp00_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp11_array[RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t tmp22_array[RSA_WORDS + MULT_BUFFER_WORDLEN];

bigi_t tmpary_bigi[TMPARY_LEN];
bigi_t tmp0_bigi, tmp1_bigi, tmp2_bigi, tmp3_bigi, tmp00_bigi, tmp11_bigi, tmp22_bigi;

word_t  p_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  q_array  [(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  n_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  e_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
word_t  d_array  [RSA_WORDS + MULT_BUFFER_WORDLEN];
bigi_t p_bigi, q_bigi, n_bigi, e_bigi, d_bigi;

word_t  dp_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  dq_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
word_t  qi_array[(RSA_WORDS >> 1) + MULT_BUFFER_WORDLEN];
bigi_t dp_bigi, dq_bigi, qi_bigi;

word_t mu_mult;
word_t index_value;

/*BIGI PART - END  */

void rsa_init(void) {
    uint16_t i;
    plaintext_bigi.ary = plaintext_array;
    plaintext_bigi.wordlen = RSA_WORDS;
    plaintext_bigi.domain = DOMAIN_NORMAL;

    ciphertext_bigi.ary = ciphertext_array;
    ciphertext_bigi.wordlen = RSA_WORDS;
    ciphertext_bigi.domain = DOMAIN_NORMAL;

    p_bigi.ary = p_array;
    p_bigi.wordlen = (RSA_WORDS >> 1);
    p_bigi.domain = DOMAIN_NORMAL;

    q_bigi.ary = q_array;
    q_bigi.wordlen = (RSA_WORDS >> 1);
    q_bigi.domain = DOMAIN_NORMAL;

    n_bigi.ary = n_array;
    n_bigi.wordlen = RSA_WORDS;
    n_bigi.domain = DOMAIN_NORMAL;

    e_bigi.ary = e_array;
    e_bigi.wordlen = RSA_WORDS;
    e_bigi.domain = DOMAIN_NORMAL;

    d_bigi.ary = d_array;
    d_bigi.wordlen = RSA_WORDS;
    d_bigi.domain = DOMAIN_NORMAL;

    dp_bigi.ary = dp_array;
    dp_bigi.wordlen = (RSA_WORDS >> 1);
    dp_bigi.domain = DOMAIN_NORMAL;

    dq_bigi.ary = dq_array;
    dq_bigi.wordlen = (RSA_WORDS >> 1);
    dq_bigi.domain = DOMAIN_NORMAL;

    qi_bigi.ary = qi_array;
    qi_bigi.wordlen = (RSA_WORDS >> 1);
    qi_bigi.domain = DOMAIN_NORMAL;

    for (i = 0; i < TMPARY_LEN; i++)
    {
        tmpary_bigi[i].ary = &tmp_arys[i * (RSA_WORDS + MULT_BUFFER_WORDLEN)];
        tmpary_bigi[i].wordlen = RSA_WORDS;
        tmpary_bigi[i].alloclen = RSA_WORDS;
        tmpary_bigi[i].domain = DOMAIN_NORMAL;
    }

    tmp0_bigi.ary = tmp0_array;
    tmp0_bigi.wordlen = RSA_WORDS >> 1;
    tmp0_bigi.alloclen = RSA_WORDS >> 1;
    tmp0_bigi.domain = DOMAIN_NORMAL;

    tmp1_bigi.ary = tmp1_array;
    tmp1_bigi.wordlen = RSA_WORDS >> 1;
    tmp1_bigi.alloclen = RSA_WORDS >> 1;
    tmp1_bigi.domain = DOMAIN_NORMAL;

    tmp2_bigi.ary = tmp2_array;
    tmp2_bigi.wordlen = RSA_WORDS >> 1;
    tmp2_bigi.alloclen = RSA_WORDS >> 1;
    tmp2_bigi.domain = DOMAIN_NORMAL;

    tmp3_bigi.ary = tmp3_array;
    tmp3_bigi.wordlen = RSA_WORDS >> 1;
    tmp3_bigi.alloclen = RSA_WORDS >> 1;
    tmp3_bigi.domain = DOMAIN_NORMAL;

    tmp00_bigi.ary = tmp00_array;
    tmp00_bigi.wordlen = RSA_WORDS;
    tmp00_bigi.alloclen = RSA_WORDS;
    tmp00_bigi.domain = DOMAIN_NORMAL;

    tmp11_bigi.ary = tmp11_array;
    tmp11_bigi.wordlen = RSA_WORDS;
    tmp11_bigi.alloclen = RSA_WORDS;
    tmp11_bigi.domain = DOMAIN_NORMAL;

    tmp22_bigi.ary = tmp22_array;
    tmp22_bigi.wordlen = RSA_WORDS;
    tmp22_bigi.alloclen = RSA_WORDS;
    tmp22_bigi.domain = DOMAIN_NORMAL;

    /*Decoding hex to bigi structs*/
    dbg_puts_labeled("after hex decoding");
    //length in chars...
    bigi_from_hex(RSA_P,  RSA_BYTES,     &p_bigi);
    bigi_from_hex(RSA_Q,  RSA_BYTES,     &q_bigi);
    bigi_from_hex(RSA_N,  RSA_BYTES << 1,&n_bigi);
    bigi_from_hex(RSA_D,  RSA_BYTES << 1,&d_bigi);
    bigi_from_hex(RSA_E,  RSA_BYTES << 1,&e_bigi);
    bigi_from_hex(RSA_DP, RSA_BYTES,     &dp_bigi);
    bigi_from_hex(RSA_DQ, RSA_BYTES,     &dq_bigi);
    bigi_from_hex(RSA_QI, RSA_BYTES,     &qi_bigi);
    dbg_print_bigi("P", &p_bigi);
    dbg_print_bigi("Q", &q_bigi);
    dbg_print_bigi("E", &e_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("D", &d_bigi);
    dbg_print_bigi("Dp", &dp_bigi);
    dbg_print_bigi("Dq", &dq_bigi);
    dbg_print_bigi("Qinv", &qi_bigi);

#ifdef HW_IMPLEMENTATION
    p_buff8_array.len = RSA_BYTES >> 1;
    q_buff8_array.len = RSA_BYTES >> 1;
    e_buff8_array.len = RSA_BYTES;
    d_buff8_array.len = RSA_BYTES;
    n_buff8_array.len = RSA_BYTES;
    m_buff8_array.len = RSA_BYTES;
    c_buff8_array.len = RSA_BYTES;
    dp_buff8_array.len = RSA_BYTES >> 1;
    dq_buff8_array.len = RSA_BYTES >> 1;
    qi_buff8_array.len = RSA_BYTES >> 1;

    p_buff8_array.pd = (char*)&p_io_byte_ary[0];
    q_buff8_array.pd = (char*)&q_io_byte_ary[0];
    e_buff8_array.pd = (char*)&e_io_byte_ary[0];
    d_buff8_array.pd = (char*)&d_io_byte_ary[0];
    n_buff8_array.pd = (char*)&n_io_byte_ary[0];
    m_buff8_array.pd = (char*)&m_io_byte_ary[0];
    c_buff8_array.pd = (char*)&c_io_byte_ary[0];
    dp_buff8_array.pd = (char*)&dp_io_byte_ary[0];
    dq_buff8_array.pd = (char*)&dq_io_byte_ary[0];
    qi_buff8_array.pd = (char*)&qi_io_byte_ary[0];

    bigi_to_bytes(p_buff8_array.pd, RSA_BYTES >> 1, &p_bigi);
    bigi_to_bytes(q_buff8_array.pd, RSA_BYTES >> 1, &q_bigi);
    bigi_to_bytes(e_buff8_array.pd, RSA_BYTES,      &e_bigi);
    bigi_to_bytes(d_buff8_array.pd, RSA_BYTES,      &d_bigi);
    bigi_to_bytes(n_buff8_array.pd, RSA_BYTES,      &n_bigi);
    bigi_to_bytes(dp_buff8_array.pd, RSA_BYTES >> 1, &dp_bigi);
    bigi_to_bytes(dq_buff8_array.pd, RSA_BYTES >> 1, &dq_bigi);
    bigi_to_bytes(qi_buff8_array.pd, RSA_BYTES >> 1, &qi_bigi);

    dbg_puts_labeled("ARRAYS:");
    dbg_print_array("Q",    q_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("P",    p_buff8_array.pd , RSA_BYTES >> 1);
    dbg_print_array("E",    e_buff8_array.pd , RSA_BYTES);
    dbg_print_array("N",    n_buff8_array.pd , RSA_BYTES);
    dbg_print_array("D",    d_buff8_array.pd , RSA_BYTES);
    dbg_print_array("Dp",   dp_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Dq",   dq_buff8_array.pd, RSA_BYTES >> 1);
    dbg_print_array("Qinv", qi_buff8_array.pd, RSA_BYTES >> 1);


    rsa_status = PKE_RET_OK;
    dbg_puts_labeled("STARTING PKE");
    pke_power(0x01);
    while(pke_busy() == 0x01);


    /*clean all slots*/
    dbg_puts_labeled("CLEANING SLOTS");
    pke_scm_clear_slot(0);
    pke_scm_clear_slot(6);
    pke_scm_clear_slot(8);
    pke_scm_clear_slot(0xA);
    pke_scm_clear_slot(0xB);
    pke_scm_clear_slot(0xC);

    rsa_status = rsa_load_key(RSA_BITS, &d_buff8_array, &n_buff8_array, &e_buff8_array, BIG_ENDIAN); 
    /*(uint16_t rsa_bit_len, const BUFF8_T *private_exponent, const BUFF8_T *public_modulus, const BUFF8_T *public_exponent, bool msbf)*/
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN LOADING RSA KEY");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_load_crt_params(RSA_BITS, &dp_buff8_array, &dq_buff8_array, &qi_buff8_array, BIG_ENDIAN);
    //uint8_t pke_rsa_load_crt_params(uint16_t rsa_bit_len, const BUFF8_T *dp, const BUFF8_T *dq, const BUFF8_T *I, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    rsa_status = rsa_crt_gen_params(RSA_BITS, &p_buff8_array, &q_buff8_array, &n_buff8_array, &d_buff8_array, BIG_ENDIAN);
    //(uint16_t rsa_bit_len, const BUFF8_T* p, const BUFF8_T* q, const BUFF8_T* pubmod, const BUFF8_T* prvexp, bool msbf)
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN GENERATING CRT PARAMS");
        return;
    }
    while(pke_busy() == 1) asm nop;

    
#ifdef DBG
    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 8, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 8", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 6, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 6", &test_array, RSA_BYTES);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES, 0, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot 0", &test_array, RSA_BYTES);


    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xA, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot A", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xB, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot B", &test_array, RSA_BYTES >> 1);

    bytes_read = pke_read_scm(&test_array[0], RSA_BYTES >> 1, 0xC, BIG_ENDIAN);
    if (bytes_read != (RSA_BYTES >> 1)) {
        dbg_puts_labeled("WRONG NUMBER OF BYTES READ");
    }
    dbg_print_array("Slot C", &test_array, RSA_BYTES >> 1);
#endif /*DBG*/

    dbg_puts_labeled("KEY GENERATED");

#endif /*HW_IMPLEMENTATION*/
}




uint8_t rsa_enc(char* plaintext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, plaintext, plaintext_byte_array);
#ifdef HW_IMPLEMENTATION
    m_buff8_array.pd = (char*)&plaintext_byte_array[0];
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_encrypt(RSA_BITS, &m_buff8_array, BIG_ENDIAN);
    pke_start(0);
    while(pke_busy() == 1) asm nop;
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN ENCRYPTING");
        return 0x01;
    }

    trigger_low();

    pke_read_scm(&ciphertext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    dbg_print_array("CIPHERTEXT", &ciphertext_byte_array, RSA_BYTES);
#else
    //load plaintext to bigi_t
    bigi_from_bytes(&plaintext_bigi, plaintext_byte_array, RSA_BYTES);
    dbg_print_bigi("PLAINTEXT", &plaintext_bigi);
    dbg_print_bigi("N", &n_bigi);
    dbg_print_bigi("E", &e_bigi);
#ifdef MONTGOMERY
    bigi_get_mont_params(&n_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi, &mu_mult);
    dbg_print_bigi("R", &tmp00_bigi);
    bigi_mod_exp_mont(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &ciphertext_bigi);
#else
    bigi_set_zero(&tmp00_bigi);
    bigi_mod_exp(&plaintext_bigi, &e_bigi, &n_bigi, &tmp00_bigi, &ciphertext_bigi);
#endif /*MONTGOMERY*/
    dbg_print_bigi("CIPHERTEXT", &ciphertext_bigi);
    bigi_to_bytes(ciphertext_byte_array, RSA_BYTES, &ciphertext_bigi);
    /*sending part*/
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, ciphertext_byte_array, RSA_BYTES);
    return 0x00;
}

uint8_t rsa_crt_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
#ifdef HW_IMPLEMENTATION
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT(IN)", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;
    
    trigger_high();

    rsa_status = rsa_crt_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;
    
    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT(OUT)", &plaintext_byte_array, RSA_BYTES);
#else
    bigi_from_bytes(&ciphertext_bigi, ciphertext_byte_array, RSA_BYTES);
    dbg_print_bigi("CIPHERTEXT(IN)", &ciphertext_bigi);
    /*decryption part*/
    trigger_high();
    //m1 = C^Dp mod P
#ifdef MONTGOMERY
    //tmp0 = C mod P
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_high();
#endif /*CP_GLITCH || M1_GLITCH*/
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
#if defined(CP_GLITCH) || defined(M1_GLITCH)
    trigger_low();
#endif /*CP_GLITCH || M1_GLITCH*/
    dbg_print_bigi("Cp", &tmp1_bigi);
#ifdef CP_GLITCH
    memset(plaintext_byte_array, 0, RSA_BYTES);
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES >> 1 , &tmp1_bigi);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    trigger_low();
    return 0x00;
#endif /*CP_GLITCH*/

    //m1 = tmp0^Dp mod P
    bigi_get_mont_params(&p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi, &mu_mult);
    dbg_print_bigi("R-m1", &tmp2_bigi);
    bigi_mod_exp_mont(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_get_mont_params(&q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp3_bigi, &mu_mult);
    dbg_print_bigi("R-m2", &tmp3_bigi);
    bigi_mod_exp_mont(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, mu_mult, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#else
    //tmp0 = C mod P
    bigi_mod_red(&ciphertext_bigi, &p_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp1_bigi);
    dbg_print_bigi("Cp", &tmp1_bigi);
    //m1 = tmp0^Dp mod P
    bigi_mod_exp(&tmp1_bigi, &dp_bigi, &p_bigi, &tmp2_bigi, &tmp0_bigi);
    dbg_print_bigi("M1", &tmp0_bigi);
    //tmp0 = C mod Q
    bigi_mod_red(&ciphertext_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp2_bigi);
    dbg_print_bigi("Cq", &tmp2_bigi);
    //m2 = tmp0^Dq mod Q
    bigi_mod_exp(&tmp2_bigi, &dq_bigi, &q_bigi, &tmp3_bigi, &tmp1_bigi);
    dbg_print_bigi("M2", &tmp1_bigi);
#endif /*MONTGOMERY*/
    //h  = (m1 - m2) * qi mod P
        // tmp2 = m1 - m2
    bigi_sub(&tmp0_bigi, &tmp1_bigi, &tmp2_bigi);
    dbg_print_bigi("M1 - M2", &tmp2_bigi);

    /* Check if result is negative number, then add P */
    index_value = 0;
    bigi_get_bit(&tmp2_bigi, ((RSA_BITS >> 1) + 1), &index_value);
    if (index_value == 1) {
        dbg_puts_labeled("A LOWER than B");
        bigi_add(&tmp2_bigi, &p_bigi, &tmp0_bigi);
        dbg_print_bigi("M1 - M2 + p", &tmp0_bigi);
    }
    else {
        dbg_puts_labeled("A GREATER than B");
        bigi_copy(&tmp0_bigi, &tmp2_bigi);
        dbg_print_bigi("M1 - M2", &tmp0_bigi);
    }

    // tmp0 * qi mod P
    bigi_mod_mult(&tmp0_bigi, &qi_bigi, &p_bigi, &tmp2_bigi);
    dbg_print_bigi("H", &tmp2_bigi);

    // m = m2 + h * Q
        // tmp00 = h * Q
    bigi_mult_fit(&tmp2_bigi, &q_bigi, &tmpary_bigi[0], TMPARY_LEN, &tmp00_bigi);
    dbg_print_bigi("H * Q", &tmp00_bigi);
    // m2 + tmp00
    bigi_add(&tmp1_bigi, &tmp00_bigi, &plaintext_bigi);
    dbg_print_bigi("PLAINTEXT(OUT)", &plaintext_bigi);
    /*sending part*/
    trigger_low();
    bigi_to_bytes(plaintext_byte_array, RSA_BYTES, &plaintext_bigi);
#endif /*HW_IMPLEMENTATION*/
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}

#ifdef HW_IMPLEMENTATION
uint8_t rsa_dec(char* ciphertext, uint8_t* output) {
    /*parsing part*/
    hex_decode(RSA_BYTES, ciphertext, ciphertext_byte_array);
    c_buff8_array.pd = (char*)&ciphertext_byte_array[0];
    dbg_print_array("CIPHERTEXT", c_buff8_array.pd, RSA_BYTES);
    rsa_status =  PKE_RET_OK;

    trigger_high();

    rsa_status = rsa_decrypt(RSA_BITS, &c_buff8_array, BIG_ENDIAN);
    pke_start(0);
    if (rsa_status != PKE_RET_OK) {
        dbg_puts_labeled("ERROR WHEN DECRYPTING");
        return 0x01;
    }
    while(pke_busy() == 1) asm nop;

    trigger_low();

    bytes_read = pke_read_scm(&plaintext_byte_array[0], RSA_BYTES, 5, BIG_ENDIAN);
    
    if (bytes_read != RSA_BYTES) {
        dbg_puts_labeled("PLAINTEXT WAS NOT READ");
        return 0x01;
    }
    dbg_print_array("PLAINTEXT", &plaintext_byte_array, RSA_BYTES);
    memcpy(output, plaintext_byte_array, RSA_BYTES);
    return 0x00;
}
#endif /*HW_IMPLEMENTATION*/


uint8_t buf[128];
uint8_t real_crt_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_crt_dec(RSA_CT, buf);
    
#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256

    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#ifdef HW_IMPLEMENTATION
uint8_t real_dec(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_dec(RSA_CT, buf);

    simpleserial_put('r', 48, buf);

    return ret;
}
#endif /*HW_IMPLEMENTATION*/

uint8_t real_enc(uint8_t *pt)
{
    int ret = 0;
    ret = rsa_enc(RSA_PT, buf);

#if RSA_BITS == 1024

    simpleserial_put('r', 48, buf);

#elif RSA_BITS == 256
    
    simpleserial_put('r', RSA_BYTES, buf);

#endif /*RSA_BITS*/
    return ret;
}

#if RSA_BITS > 512

uint8_t sig_chunk_1(uint8_t *pt)
{
     simpleserial_put('r', 48, buf + 48);
     return 0x00;
}

uint8_t sig_chunk_2(uint8_t *pt)
{
     simpleserial_put('r', RSA_BYTES - 48 * 2, buf + 48*2);
     return 0x00;
}

#endif /*RSA_BITS > 512*/