#include "functions.h"
#include "../debug.h"
#include "../simpleserial/simpleserial.h"
#include "../device_setup/cec1702_setup.h"

static uint32_t outbuf[4] aligned(16);


extern ss_cmd commands[MAX_SS_CMDS];
extern int num_commands;

uint8_t echo(uint8_t* pt) {
        if (!pt || !outbuf) {
           return 0x01;
        }
        trigger_high();
        memcpy(outbuf, pt, 16);
        Delay_ms(100);
        trigger_low();
        simpleserial_put('r', 16, outbuf);
        return 0x00;
}

uint8_t only_return (uint8_t* pt) {
        return 0x00;
}

uint8_t reset(uint8_t* params) {
        return 0x00;
}

uint8_t check_version(uint8_t* v) {
        return 0x00;
}