/*
    This file is part of the ChipWhisperer Example Targets
    Copyright (C) 2016-2017 NewAE Technology Inc.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "rsa_implementation.h"
#include "simpleserial/simpleserial.h"
#include "device_setup/cec1702_setup.h"
#include "debug.h"
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

int main(void)
{
    platform_init();
    init_uart();
    trigger_setup();

    /* Load all the keys etc */
    rsa_init();
    simpleserial_init();
    dbg_puts_labeled("INIT DONE");
    simpleserial_addcmd('c', 0,  real_crt_dec);
#ifdef HW_IMPLEMENTATION
    simpleserial_addcmd('r', 0,  real_dec);
#endif /*HW_IMPLEMENTATION*/
    simpleserial_addcmd('p', 0,  real_enc);
    
#if RSA_BITS > 512
    simpleserial_addcmd('1', 0,  sig_chunk_1);
    simpleserial_addcmd('2', 0,  sig_chunk_2);
#endif //RSA_BITS > 512
    while(1)
        simpleserial_get();
}